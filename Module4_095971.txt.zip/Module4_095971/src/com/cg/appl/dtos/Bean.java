package com.cg.appl.dtos;

import java.io.Serializable;







import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name = "abc")
@Table(name="employee")
public class Bean implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private String firstName;
	private String lastName;
	private String post;
	
	public Bean() {
		// TODO Auto-generated constructor stub
	}

	public Bean(int id, String firstName, String lastName, String post) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.post = post;
	}

	@Id
	@Column(name="id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="firstNm")
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@NotEmpty(message="Lastname is mandatory")
	@Size(min=3,max=10,message="Minimum 3 and maximum 10 characters required")
	@Column(name="lastNm")
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Column(name="post")
	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bean other = (Bean) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bean [id=" + id + ", firstName=" + firstName + ", lastName="
				+ lastName + ", post=" + post + "]";
	}
	
	
	
}
