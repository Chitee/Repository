package com.cg.appl.daos;

import java.io.Serializable;
import java.util.List;

import com.cg.appl.dtos.Bean;




public interface Dao extends Serializable {
	boolean updateEmployee(Bean emp);
	Bean getEmployee(int id);
	List<Bean> getAllEmployees();
}
