package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.appl.daos.Dao;
import com.cg.appl.dtos.Bean;


@Service("abcServices")
@Transactional
public class ServicesImpl implements Services {
	
	private static final long serialVersionUID = 1L;
	
	@Resource(name="abcDao")
	private Dao dao;

	@Override
	public Bean getEmployee(int id) {
		
			return dao.getEmployee(id);
		
		
	}

	@Override
	public List<Bean> getAllEmployees() {
		
			return dao.getAllEmployees();
		
		
	}

	@Override
	public boolean updateEmployee(Bean emp) {
		
			return dao.updateEmployee(emp);
		
	}

}
