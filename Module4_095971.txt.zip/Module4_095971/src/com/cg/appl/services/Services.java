package com.cg.appl.services;

import java.io.Serializable;
import java.util.List;

import com.cg.appl.dtos.Bean;


public interface Services extends Serializable {
	boolean updateEmployee(Bean emp);
	Bean getEmployee(int id);
	List<Bean> getAllEmployees();
	
	

}
