package com.cg.appl.controller;

import java.util.List;

import javax.annotation.Resource;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;








import com.cg.appl.dtos.Bean;

import com.cg.appl.services.Services;

@Controller
public class WebController {
	
	@Resource(name="abcServices")
	private Services service;
	
	
	
	
	@RequestMapping(value="/listAll")
	public String seeAllRecords(Model model){
		
			System.out.println("In listEmployees");
			List<Bean> list= service.getAllEmployees();
			
			model.addAttribute("listEmp",list);
			
			return "listEmployees";
		
		
	}
	
	@RequestMapping(value="/employeeDetails")
	public String getEmployeeDetails(@RequestParam("id") int empId, Model model ) {
		
			System.out.println(empId);
			
			Bean employee=service.getEmployee(empId);
			System.out.println(employee);
		
			model.addAttribute("employee",employee);
			model.addAttribute("post",new String[]{"executive","assistant","associate"});
			
			return "updateEmpForm";
	
		
	}
	
	@RequestMapping(value="/updateEmployee", method=RequestMethod.POST)
	public String postEmployeeData(@ModelAttribute("employee") @Valid Bean employee, BindingResult result, Model model){
		
			if(result.hasErrors()){
				
				//model.addAttribute("post",new String[]{"executive","assistant","associate"});
				return "updateEmpForm";
				
			}
			else{
			
			boolean isUpdated=service.updateEmployee(employee);
			System.out.println("Is employee updated?" +isUpdated);
			
			return isUpdated?"success":"updateEmpForm";
		
		}
		
		
	}
	

}
