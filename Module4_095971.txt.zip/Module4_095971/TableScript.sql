drop table employee cascade constraints;
 create table employee(
	  id number(4) primary key,
	  firstNm varchar2(10),
	  lastNm varchar2(10),
	  post varchar2(50)
	 );
	 
	 
alter table employee
add post varchar2(50);