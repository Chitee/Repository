/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.factory;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil 
{
	public static Connection getConnection() 
			throws SQLException, ClassNotFoundException
	{
		
		Connection connection = null;
		
		try
		{
			InitialContext context = new InitialContext();
			
			DataSource source = (DataSource) context
					.lookup("java:/OracleDS");
			
			connection = source.getConnection();
			
						
		} catch (Exception e) 
		{
			
			e.printStackTrace();
			
		}
		return connection;
	}
}
