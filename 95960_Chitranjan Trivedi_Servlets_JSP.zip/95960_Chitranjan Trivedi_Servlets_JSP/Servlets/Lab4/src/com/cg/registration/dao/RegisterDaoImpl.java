/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.registration.dto.User;
import com.cg.registration.factory.DBUtil;

public class RegisterDaoImpl implements RegisterDao
{

	@Override
	public void addDetails(User user) 
	{
	try(Connection con = DBUtil.getConnection()) 
	{
		PreparedStatement pstm =
				con.prepareStatement("insert into registeredusers values (?,?,?,?,?,?)");
		
		pstm.setString(1, user.getFirstName());
		pstm.setString(2, user.getLastName());
		pstm.setString(3, user.getPassword());
		pstm.setString(4, user.getGender());
		pstm.setString(5, user.getSkill());
		pstm.setString(6, user.getCity());
		
		pstm.executeUpdate();
	} 
	catch (Exception e)
	{
		// TODO: handle exception
	}	
		
	}

	@Override
	public List<User> viewAll() 
	{
		ArrayList<User> list = new ArrayList<>();
		
		try(Connection con = DBUtil.getConnection())
		{
			User user = new User();
			PreparedStatement pstm =
					con.prepareStatement("select * from registeredusers");
			
			ResultSet res = 
					pstm.executeQuery();
			
			while(res.next())
			{
				user.setFirstName(res.getString(1));
				user.setFirstName(res.getString(2));
				user.setFirstName(res.getString(3));
				user.setFirstName(res.getString(4));
				user.setFirstName(res.getString(5));
				user.setFirstName(res.getString(6));
				
				list.add(user);
			}
			
			
		} catch (Exception e) 
		{
			// TODO: handle exception
		}
		return list;
	}




}
