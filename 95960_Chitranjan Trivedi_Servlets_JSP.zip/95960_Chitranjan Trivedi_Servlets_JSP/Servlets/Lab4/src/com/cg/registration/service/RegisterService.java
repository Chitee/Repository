/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.service;

import java.util.HashMap;
import java.util.List;

import com.cg.registration.dto.User;

public interface RegisterService 
{
	public void addDetails(HashMap<String, String> details);
	public List<User> viewAll() ;
}
