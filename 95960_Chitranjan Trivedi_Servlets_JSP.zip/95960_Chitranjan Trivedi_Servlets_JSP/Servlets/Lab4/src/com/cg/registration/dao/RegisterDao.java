/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.dao;

import java.util.List;

import com.cg.registration.dto.User;

public interface RegisterDao 
{
	public void addDetails(User user);
	public List<User> viewAll() ;
}
