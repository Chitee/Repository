/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.registration.dto.User;
import com.cg.registration.service.RegisterService;
import com.cg.registration.service.RegisterServiceImpl;

/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RegisterService registerService;
       
    
    public Display() {
        super();
        registerService= new RegisterServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String firstname = request.getParameter("firstname");
		String lastname= request.getParameter("lastname");
		String password= request.getParameter("password");
		String gender= request.getParameter("gender");
		String skill= request.getParameter("skill");
		String city = request.getParameter("city");
		
		List<User> list = registerService.viewAll();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		out.println("Your details");
		out.println("<p>First name "+firstname+ "</p>");
		out.println("<p>Last name "+lastname+ "</p>");
		out.println("<p>Password "+password+ "</p>");
		out.println("<p>Gender "+gender+ "</p>");
		out.println("<p>Skill "+skill+ "</p>");
		out.println("<p>City "+city+ "</p>");
		
		out.println("</body>");
		out.println("</html>");
	}

}
