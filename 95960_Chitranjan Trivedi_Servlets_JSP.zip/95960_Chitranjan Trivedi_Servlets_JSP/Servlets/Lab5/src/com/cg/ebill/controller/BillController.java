/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ebill.dto.Bill;
import com.cg.ebill.service.BillService;
import com.cg.ebill.service.BillServiceImpl;


@WebServlet("/BillController")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      BillService billService;
      final int fixedCharge= 100;
      
      
    public BillController() {
        super();
        billService = new BillServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

String action = request.getParameter("action");
		
		switch(action)
		{
		case "calculate" :
		{
			Bill b = new Bill();
			
			int consumerNum = Integer.parseInt(request.getParameter("consumerNum"));
			float lastMonth = Float.parseFloat(request.getParameter("lastMonth"));
			float currentMonth = Float.parseFloat(request.getParameter("currentMonth"));
			
			float unitsConsumed;
			unitsConsumed = lastMonth - currentMonth;
			float netAmt;
			
			if(unitsConsumed < 0){
				unitsConsumed = -unitsConsumed;
				netAmt = (float) ((unitsConsumed * 1.15) + fixedCharge);
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				

				out.println("<html>");
				out.println("<head>");
				out.println("</head>");
				out.println("<body>");
				out.println("Welcome <br/>");
				out.println("<p><h1> Electricity Bill for Consumer Number - " +consumerNum+ " is</h1></p>");
				out.println("<br/>");
				out.println("<p>Unit Consumed :: "+unitsConsumed+ "</p>");
				out.println("<p>Net Amount :: "+netAmt+ "</p>");
				out.println("</body>");
				out.println("</html>");
			}
			else{
			netAmt = (float) ((unitsConsumed * 1.15) + fixedCharge);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			

			out.println("<html>");
			out.println("<head>");
			out.println("</head>");
			out.println("<body>");
			out.println("Welcome <br/>");
			out.println("<p><h1> Electricity Bill for Consumer Number - " +consumerNum+ " is</h1></p>");
			out.println("<br/>");
			out.println("<p>Unit Consumed :: "+unitsConsumed+ "</p>");
			out.println("<p>Net Amount :: "+netAmt+ "</p>");
			out.println("</body>");
			out.println("</html>");
			}
			
			b.setConsumerNum(Integer.parseInt(request.getParameter("consumerNum")));
			b.setCurrentReading(Float.parseFloat(request.getParameter("currentMonth")));
			b.setUnitConsumed(unitsConsumed);
			b.setNetAmount(netAmt);
			
			billService.acceptDetails(b);
			
			
		}
		
		}
		
	}
}

