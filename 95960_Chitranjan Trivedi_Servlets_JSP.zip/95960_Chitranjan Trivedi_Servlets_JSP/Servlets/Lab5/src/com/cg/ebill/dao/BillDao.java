/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.ebill.dao;

import com.cg.ebill.dto.Bill;

public interface BillDao
{
	public void acceptDetails(Bill b);
}
