/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.ebill.service;

import com.cg.ebill.dao.BillDao;
import com.cg.ebill.dao.BillDaoImpl;
import com.cg.ebill.dto.Bill;

public class BillServiceImpl implements BillService
{
	BillDao billDao;
	
	public BillServiceImpl() {
		
	billDao = new BillDaoImpl();
	}
	@Override
	public void acceptDetails(Bill b)
	{
		billDao.acceptDetails(b);
		
	}

}
