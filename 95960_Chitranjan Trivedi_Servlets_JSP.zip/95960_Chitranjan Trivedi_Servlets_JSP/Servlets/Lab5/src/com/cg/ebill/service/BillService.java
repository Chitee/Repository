/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.ebill.service;

import com.cg.ebill.dto.Bill;

public interface BillService 
{
	public void acceptDetails(Bill b);
	
}
