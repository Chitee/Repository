/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;

import com.cg.ebill.dto.Bill;
import com.cg.ebill.factory.DBUtil;

public class BillDaoImpl implements BillDao
{

	@Override
	public void acceptDetails(Bill b) 
	{
//		LocalDate sysdate = LocalDate.now();
		
		try (Connection con = DBUtil.getConnection())
		{
			PreparedStatement pstm;
			pstm = con.prepareStatement
					("INSERT INTO  BillDetails VALUES (seq_bill_num.nextval, ?,?,?,?,SYSDATE)");
			
			pstm.setInt(1, b.getConsumerNum());
			pstm.setFloat(2, b.getCurrentReading());
			pstm.setFloat(3, b.getUnitConsumed());
			pstm.setFloat(4, b.getNetAmount());
			
			pstm.executeUpdate();
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}

}
