/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.ebill.dto;

import java.io.Serializable;
import java.sql.Date;

public class Bill implements Serializable
{
	private int billNum;
	private int consumerNum;
	private float currentReading;
	private float unitConsumed;
	private float netAmount;
	private Date billDate;
	
	
	public Bill() {
		// TODO Auto-generated constructor stub
	}


	public Bill(int billNum, int consumerNum, float currentReading,
			float unitConsumed, float netAmount, Date billDate) {
		super();
		this.billNum = billNum;
		this.consumerNum = consumerNum;
		this.currentReading = currentReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.billDate = billDate;
	}


	public int getBillNum() {
		return billNum;
	}


	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}


	public int getConsumerNum() {
		return consumerNum;
	}


	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}


	public float getCurrentReading() {
		return currentReading;
	}


	public void setCurrentReading(float currentReading) {
		this.currentReading = currentReading;
	}


	public float getUnitConsumed() {
		return unitConsumed;
	}


	public void setUnitConsumed(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}


	public float getNetAmount() {
		return netAmount;
	}


	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}


	public Date getBillDate() {
		return billDate;
	}


	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}


	@Override
	public String toString() {
		return "Bill [billNum=" + billNum + ", consumerNum=" + consumerNum
				+ ", currentReading=" + currentReading + ", unitConsumed="
				+ unitConsumed + ", netAmount=" + netAmount + ", billDate="
				+ billDate + "]";
	}
	
	
}
