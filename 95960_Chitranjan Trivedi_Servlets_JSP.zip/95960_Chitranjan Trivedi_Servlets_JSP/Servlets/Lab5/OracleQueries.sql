CREATE table Consumers(
		consumer_num NUMBER(6) PRIMARY KEY,
		consumer_name VARCHAR(20) NOT NULL,
		address VARCHAR(30)
	);
	
INSERT INTO Consumers values(100001, 'Sumeet', 'Shivaji Nagar, Pune');
INSERT INTO Consumers values(100002, 'Meenal', 'M G Colony Panvel, Mumbai');
INSERT INTO Consumers values(100003, 'Neeraj', 'Whitefield, Bangalore');
INSERT INTO Consumers values(100004, 'Arul', 'Karapakkam, Chennai');

commit;

CREATE table BillDetails(
	bill_num NUMBER(6) PRIMARY KEY,
	consumer_num NUMBER(6) REFERENCES Consumers(consumer_num),
	cur_reading NUMBER(5,2),
	unitConsumed NUMBER(5,2),
	netAmount NUMBER(5,2),
	bill_date DATE DEFAULT SYSDATE);
	
	CREATE SEQUENCE seq_bill_num START WITH 100;
	
	commit;


