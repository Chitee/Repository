/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.controller;

import java.io.IOException;




import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.registration.service.RegisterService;
import com.cg.registration.service.RegisterServiceImpl;


@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     private RegisterService registerService;  
    
    public RegistrationController() 
    {
                registerService= new RegisterServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		
		switch(action)
		{
		case "add" :
		{
			String firstname = request.getParameter("firstname");
			String lastname= request.getParameter("lastname");
			String password= request.getParameter("password");
			String gender= request.getParameter("gender");
			String skill= request.getParameter("skill");
			String city = request.getParameter("city");
			
			HashMap<String, String> details = new HashMap<>();
			
			details.put("firstname", firstname);
			details.put("lastname", lastname);
			details.put("password", password);
			details.put("gender", gender);
			details.put("skill", skill);
			details.put("city", city);
			
			
			registerService.addDetails(details);
			try
			{
			RequestDispatcher rd  =
					request.getRequestDispatcher("success.html");
			
			rd.forward(request, response);
			}
			catch(Exception e)
			{
				RequestDispatcher rd= 
						request.getRequestDispatcher("failure.html");
				
				rd.forward(request, response);
				e.printStackTrace();
			}
			
		}
		
		}
	}

}
