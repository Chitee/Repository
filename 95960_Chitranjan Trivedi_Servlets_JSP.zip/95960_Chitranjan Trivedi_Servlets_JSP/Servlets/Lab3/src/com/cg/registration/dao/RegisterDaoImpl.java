/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cg.registration.dto.User;
import com.cg.registration.factory.DBUtil;

public class RegisterDaoImpl implements RegisterDao
{

	@Override
	public void addDetails(User user) 
	{
	try(Connection con = DBUtil.getConnection()) 
	{
		PreparedStatement pstm =
				con.prepareStatement("insert into registeredusers values (?,?,?,?,?,?)");
		
		pstm.setString(1, user.getFirstName());
		pstm.setString(2, user.getLastName());
		pstm.setString(3, user.getPassword());
		pstm.setString(4, user.getGender());
		pstm.setString(5, user.getSkill());
		pstm.setString(6, user.getCity());
		
		pstm.executeUpdate();
	} 
	catch (Exception e)
	{
		// TODO: handle exception
	}	
		
	}

}
