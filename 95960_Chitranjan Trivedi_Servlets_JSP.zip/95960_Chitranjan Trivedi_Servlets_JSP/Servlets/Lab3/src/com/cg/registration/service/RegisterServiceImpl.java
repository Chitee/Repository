/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.service;

import java.util.HashMap;

import com.cg.registration.dao.RegisterDao;
import com.cg.registration.dao.RegisterDaoImpl;
import com.cg.registration.dto.User;

public class RegisterServiceImpl implements RegisterService
{
	private RegisterDao registerDao;
	
	public RegisterServiceImpl() 
	{
		registerDao = new RegisterDaoImpl();
	}
	@Override
	public void addDetails(HashMap<String, String> details) 
	{
		User user= new User();
		
		user.setFirstName(details.get("firstname"));
		user.setLastName(details.get("lastname"));
		user.setPassword(details.get("password"));
		user.setGender(details.get("gender"));
		user.setSkill(details.get("skill"));
		user.setCity(details.get("city"));
		
		registerDao.addDetails(user);
		
	}
	
}
