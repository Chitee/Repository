/**
 *  @author  Chitranjan Trivedi
* 	@version 1.0
* 	
 */
package com.cg.registration.dao;

import com.cg.registration.dto.User;

public interface RegisterDao
{
	public void addDetails(User user);
}
