Create table RegisteredUsers 
(firstname VARCHAR(20),lastname VARCHAR(30), password VARCHAR(12) UNIQUE,gender VARCHAR(20), skillset VARCHAR(40), city VARCHAR(12));