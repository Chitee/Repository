package com.capgemini.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.capgemini.services.PrepareBillImpl;

public class TestPerpareBill {
	
	public static void main(String[] args) {
		
	
	//Resource resource = new ClassPathResource("currencyconverter.xml");//read xml
	//BeanFactory factory = new XmlBeanFactory(resource);
	
	ApplicationContext factory = new ClassPathXmlApplicationContext("currencyconverter.xml");
	System.out.println("Constrtor Load");
	
	PrepareBillImpl prepareBill = (PrepareBillImpl) factory.getBean("prepareBill");
	
	System.out.println(prepareBill.getBill(2000));
	}
	
}
