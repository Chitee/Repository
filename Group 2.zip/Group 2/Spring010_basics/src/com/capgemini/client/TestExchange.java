package com.capgemini.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.capgemini.services.ExchangeServices;
import com.capgemini.services.ExchangeServicesImpl;

public class TestExchange {

	public static void main(String[] args) {
		/*ExchangeServices services = new ExchangeServicesImpl();
		System.out.println(services.dollarToRs(2000));*/
		
		Resource resource = new ClassPathResource("currencyconverter.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		
		ExchangeServices services1 = factory.getBean(ExchangeServicesImpl.class);
		
		System.out.println(services1.hashCode());
		
		System.out.println(services1.dollarToRs(2000));

		ExchangeServices services2 = factory.getBean(ExchangeServicesImpl.class);
		System.out.println(services2.hashCode());
	}

}
