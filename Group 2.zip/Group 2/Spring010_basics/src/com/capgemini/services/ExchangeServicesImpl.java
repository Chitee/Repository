package com.capgemini.services;

public class ExchangeServicesImpl implements ExchangeServices {
	
	private float exchangeRateDollarRs;

	public void setExchangeRateDollarRs(float exchangeRateDollarRs) { // property is exchangeRateDollarRs
		this.exchangeRateDollarRs = exchangeRateDollarRs;
	}



	@Override
	public float dollarToRs(float dollars) {
		
		return dollars*exchangeRateDollarRs;
	}

}
