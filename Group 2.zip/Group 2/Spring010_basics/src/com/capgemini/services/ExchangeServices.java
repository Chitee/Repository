package com.capgemini.services;

public interface ExchangeServices {
	public float dollarToRs(float dollars);

}
