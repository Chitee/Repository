package com.capgemini.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("exchangeServices")
public class ExchangeServicesImpl implements ExchangeServices {
	
	private float exchangeRateDollarRs;
	@Value(value="64.44")
	public void setExchangeRateDollarRs(float exchangeRateDollarRs) { // property is exchangeRateDollarRs
		this.exchangeRateDollarRs = exchangeRateDollarRs;
	}



	@Override
	public float dollarToRs(float dollars) {
		
		return dollars*exchangeRateDollarRs;
	}

}
