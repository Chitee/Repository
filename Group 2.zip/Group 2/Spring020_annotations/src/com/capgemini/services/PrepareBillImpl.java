package com.capgemini.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("prepareBill")
public class PrepareBillImpl {
	private ExchangeServices exchangeServices;
	
	public PrepareBillImpl(ExchangeServices exchangeServices) {
		
		this.exchangeServices = exchangeServices;
	}

	

	public PrepareBillImpl() {
	System.out.println("in default constr");	
	}


	@Autowired
	public void setCurrencyConverter(ExchangeServices exchangeServices) {
		System.out.println("in setter");
		this.exchangeServices = exchangeServices;
	}



	public String getBill(float amt)
	{
		return new Float(exchangeServices.dollarToRs(amt)).toString();
	}
}
