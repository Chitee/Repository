drop table employee cascade constraints;

create table employee(
	id number(10),
	name varchar(20),
	department varchar(20),
	designation varchar(20),
 	dateOfBirth varchar(20),
	dateOfJoining varchar(20),
	salary number(10,5)
);

drop table EMSUser cascade constraints;
create table EMSUser(
	id number(10),
	username varchar(20),
	password varchar(20)
);

create sequence emsuser_seq start with 1;

insert into emsuser values(emsuser_seq.nextval,'admin','root');

commit;


create sequence employeeId_seq start with 1;