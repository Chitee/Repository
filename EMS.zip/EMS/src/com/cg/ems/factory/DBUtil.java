package com.cg.ems.factory;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {

	public static Connection getConnection() throws ClassNotFoundException,
			SQLException {
		Connection connection = null;
		
		try {
			InitialContext context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:/OracleDS/MyDS");
			connection = dataSource.getConnection();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;


	}

}
