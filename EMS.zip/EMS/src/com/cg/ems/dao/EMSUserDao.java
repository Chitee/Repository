package com.cg.ems.dao;

import com.cg.ems.dto.User;
import com.cg.ems.exceptions.UserException;

public interface EMSUserDao {
	
	public void addUser(User user);
	public void listUsers();
	public boolean validateUser(User user) throws UserException;

}
