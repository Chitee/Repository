package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.dto.Employee;
import com.cg.ems.dto.User;
import com.cg.ems.exceptions.EmployeeException;


public interface EmployeeDao {

	public void addEmployee(Employee employee) throws EmployeeException;
	public void updateEmployee(Employee employee) throws EmployeeException;
	public Employee searchEmployee(Employee employee) throws EmployeeException;
	public void removeEmployee(Employee employee) throws EmployeeException;
	public List<Employee> getAllEmployee();	
}
