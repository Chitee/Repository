package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ems.dto.User;
import com.cg.ems.exceptions.EmployeeException;
import com.cg.ems.exceptions.UserException;
import com.cg.ems.factory.DBUtil;

public class EMsUserDaoImpl implements EMSUserDao {

	@Override
	public void addUser(User user) {
		
	}

	@Override
	public void listUsers() {
		
	}

	@Override
	public boolean validateUser(User user) throws UserException {
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			String query = "select * from EMSUser where username = ? AND password = ?";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, user.getUsername());
			pstm.setString(2, user.getPassword());
			ResultSet rs = pstm.executeQuery();
			if  (rs.next() == true) {
				
				return true;
			} else {
				return false;
			}
			

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("error");
			throw new UserException(e.toString());
		}
	
	}

}
