package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.User;
import com.cg.ems.exceptions.EmployeeException;
import com.cg.ems.factory.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	

	@Override
	public void addEmployee(Employee employee) throws EmployeeException {
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstm = con
					.prepareStatement("insert into employee values(employeeID_seq.nextval,?,?,?,?,?,?)");
		//	pstm.setInt(1, employee.getId());
			pstm.setString(1, employee.getName());
			pstm.setString(2, employee.getDepartment());
			pstm.setString(3, employee.getDesignation());
			pstm.setString(4, employee.getDateOfBirth());
			pstm.setString(5, employee.getDateOfJoining());
			pstm.setFloat(6, employee.getSalary());

			pstm.executeUpdate();
			System.out.println("done");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("error");
			throw new EmployeeException(e.toString());
		}
	}

	@Override
	public void updateEmployee(Employee employee) throws EmployeeException {
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			String query = "update employee set  name = ?, department = ?, designation = ?, dateOfBirth = ?, dateOfJoining = ?, salary = ? where id = ? ";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, employee.getName());
			pstm.setString(2, employee.getDepartment());
			pstm.setString(3, employee.getDesignation());
			pstm.setString(4, employee.getDateOfBirth());
			pstm.setString(5, employee.getDateOfJoining());
			pstm.setFloat(6, employee.getSalary());
			pstm.setInt(7, employee.getId());

			pstm.executeUpdate();
			System.out.println("done");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("error");
			throw new EmployeeException(e.toString());
		}
	}

	@Override
	public Employee searchEmployee(Employee employee) throws EmployeeException {
		Employee empById = new Employee();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			String query = "select * from employee where id = ?";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setInt(1, employee.getId());
			ResultSet rs = pstm.executeQuery();
			
			
			
			while (rs.next()) {
				empById.setId(rs.getInt("id"));
				empById.setName(rs.getString("name"));
				empById.setDepartment(rs.getString("department"));
				empById.setDesignation(rs.getString("designation"));
				empById.setDateOfBirth(rs.getString("dateOfBirth"));
				empById.setDateOfJoining(rs.getString("dateOfJoining"));
				empById.setSalary(rs.getFloat("salary"));
				break;
			
			}
			System.out.println("done");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("error");
			throw new EmployeeException(e.toString());
		}

		return empById;
	}

	@Override
	public void removeEmployee(Employee employee) throws EmployeeException {

		Connection con = null;
		
		if (this.searchEmployee(employee) != null) {
			
			try {
				con = DBUtil.getConnection();
				PreparedStatement pstm = con
						.prepareStatement("delete from employee where id = ?");
				pstm.setInt(1, employee.getId());
				pstm.executeUpdate();
				System.out.println("done");

			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
				System.out.println("error");
				throw new EmployeeException(e.toString());
			}
			
		} else {
			throw new EmployeeException("No Matching Record Found ...");
		}
		
		
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> empList = new ArrayList<Employee>();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			String query = "select * from employee";
			PreparedStatement pstm = con.prepareStatement(query);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				Employee emp = new Employee();
				emp.setId(rs.getInt("id"));
				emp.setName(rs.getString("name"));
				emp.setDepartment(rs.getString("department"));
				emp.setDesignation(rs.getString("designation"));
				emp.setDateOfBirth(rs.getString("dateOfBirth"));
				emp.setDateOfJoining(rs.getString("dateOfJoining"));
				emp.setSalary(rs.getFloat("salary"));
				empList.add(emp);
			}
			System.out.println("done");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("error");
			try {
				throw new EmployeeException(e.toString());
			} catch (EmployeeException e1) {
				e1.printStackTrace();
			}
		}
		return empList;
	}

	
}
