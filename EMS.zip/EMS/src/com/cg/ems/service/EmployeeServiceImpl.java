package com.cg.ems.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.ems.dao.EmployeeDao;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.User;
import com.cg.ems.exceptions.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDao employeeDao;
	
	public EmployeeServiceImpl() {
		employeeDao = new EmployeeDaoImpl();
	}

	@Override
	public void addEmployee(HashMap<String, String> empDetails)
			throws EmployeeException {
		try {
		Employee employee = new Employee();
		//employee.setId(Integer.parseInt(empDetails.get("id")));
		employee.setName(empDetails.get("name"));
		employee.setDepartment(empDetails.get("department"));
		employee.setDesignation(empDetails.get("designation"));
		employee.setDateOfBirth(empDetails.get("dateOfBirth"));
		employee.setDateOfJoining(empDetails.get("dateOfJoining"));
		employee.setSalary(Float.parseFloat(empDetails.get("salary")));
		employeeDao.addEmployee(employee);
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
		
		
	}

	@Override
	public void updateEmployee(HashMap<String, String> empDetails)
			throws EmployeeException {
		
		Employee employee = new Employee();
		employee.setId(Integer.parseInt(empDetails.get("id")));
		employee.setName(empDetails.get("name"));
		employee.setDepartment(empDetails.get("department"));
		employee.setDesignation(empDetails.get("designation"));
		employee.setDateOfBirth(empDetails.get("dateOfBirth"));
		employee.setDateOfJoining(empDetails.get("dateOfJoining"));
		employee.setSalary(Float.parseFloat(empDetails.get("salary")));
		employeeDao.updateEmployee(employee);
		
	}

	@Override
	public HashMap<String, String> searchEmployee(String id)
			throws EmployeeException {
		Employee employee  =  new Employee();
		employee.setId(Integer.parseInt(id));
		
		employee = employeeDao.searchEmployee(employee);
		
		HashMap<String, String> empDetails = new HashMap<String, String>();
		empDetails.put("id", String.valueOf(employee.getId()));
		empDetails.put("name", employee.getName());
		empDetails.put("department", employee.getDepartment());
		empDetails.put("designation", employee.getDesignation());
		empDetails.put("dateOfBirth", employee.getDateOfBirth());
		empDetails.put("dateOfJoining", employee.getDateOfJoining());
		empDetails.put("salary", String.valueOf( employee.getSalary()));
		
		
		return empDetails;
	}

	@Override
	public void removeEmployee(String id) throws EmployeeException {
		Employee emp = new Employee();
		emp.setId(Integer.parseInt(id));
		employeeDao.removeEmployee(emp);
	}

	@Override
	public List<HashMap<String, String>> getAllEmployee() {
		
		ArrayList<HashMap<String, String>> employeeDetails = new ArrayList<HashMap<String, String>>();
		List<Employee> empList = employeeDao.getAllEmployee();
		
		for (int index = 0; index < empList.size(); index++ ) {
			HashMap<String, String> empDetails = new HashMap<String, String>();
			Employee employee = empList.get(index);
			empDetails.put("id", String.valueOf(employee.getId()));
			empDetails.put("name", employee.getName());
			empDetails.put("department", employee.getDepartment());
			empDetails.put("designation", employee.getDesignation());
			empDetails.put("dateOfBirth", employee.getDateOfBirth());
			empDetails.put("dateOfJoining", employee.getDateOfJoining());
			empDetails.put("salary", String.valueOf( employee.getSalary()));
			employeeDetails.add(empDetails);
		}
		
		return employeeDetails;
	}

}
