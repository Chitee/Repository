package com.cg.ems.service;

import com.cg.ems.dto.User;
import com.cg.ems.exceptions.UserException;

public interface EMSUserService {
	
	public void addUser(User user);
	public void listUsers();
	public boolean validateUser(User user) throws UserException;

}
