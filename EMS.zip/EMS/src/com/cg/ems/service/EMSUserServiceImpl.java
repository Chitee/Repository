package com.cg.ems.service;

import com.cg.ems.dao.EMSUserDao;
import com.cg.ems.dao.EMsUserDaoImpl;
import com.cg.ems.dto.User;
import com.cg.ems.exceptions.UserException;

public class EMSUserServiceImpl implements EMSUserService{

	EMSUserDao emsDao;
	
	public EMSUserServiceImpl() {
		emsDao = new EMsUserDaoImpl();
	}
	
	
	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void listUsers() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateUser(User user) throws UserException {
		
		return emsDao.validateUser(user);
	}

}
