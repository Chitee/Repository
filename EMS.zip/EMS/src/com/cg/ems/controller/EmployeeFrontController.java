package com.cg.ems.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ems.dto.User;
import com.cg.ems.exceptions.EmployeeException;
import com.cg.ems.exceptions.UserException;
import com.cg.ems.service.EMSUserService;
import com.cg.ems.service.EMSUserServiceImpl;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeFrontController
 */
@WebServlet("/EmployeeFrontController")
public class EmployeeFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	EmployeeService employeeService;
	EMSUserService emsService;

	public EmployeeFrontController() {
		employeeService = new EmployeeServiceImpl();
		emsService = new EMSUserServiceImpl();
	}




	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}



	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session == null) {
			RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
			request.setAttribute("errorMsg", "You Need To Login First ... "
					+ "<a href = 'index.jsp'> Click Here To Login ... </a>");
			rd.forward(request, response);
			return;
		} else {
			
			
			String action = request.getParameter("action");
			System.out.println(action);
			switch (action.toLowerCase()) {

			case "logout" : {
				HttpSession usersession = request.getSession(false);
				System.out.println("done log out");
				if (usersession == null) {
					System.out.println("done log out 1");
					RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
					rd.forward(request, response);
				} else {
					/**
					 * Destroy Session
					 */
					usersession.removeAttribute("username"); // optional
					usersession.invalidate();
					System.out.println(usersession);
					System.out.println("done log out 2");
					RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
					rd.forward(request, response);
				}
				break;
			}

			case  "login" : {
				
				User user = new User();
				String username = request.getParameter("username");
				String password = request.getParameter("password");

				user.setUsername(username);
				user.setPassword(password);

				try {
					boolean isValid = emsService.validateUser(user);
					if (isValid) {

						HttpSession usersession = request.getSession(true);
						usersession.setAttribute("username", username);

						RequestDispatcher rd = request.getRequestDispatcher("chooseOptions.jsp");
						rd.forward(request, response);


					} else {
						RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
						rd.forward(request, response);
					}


				} catch ( UserException e) {
					RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMsg", e.getMessage());
					rd.forward(request, response);
				}		 

				break;
			}



			case "add": {

				

					//String id  = request.getParameter("id");
					String name  = request.getParameter("name");
					String department  = request.getParameter("department");
					String designation  = request.getParameter("designation");
					String dob  = request.getParameter("dob");
					String doj = request.getParameter("doj");
					String salary  = request.getParameter("salary");

					HashMap<String, String> empDetails = new HashMap<String, String>();

					//empDetails.put("id", id);
					empDetails.put("name", name);
					empDetails.put("department", department);
					empDetails.put("designation", designation);
					empDetails.put("dateOfBirth", dob);
					empDetails.put("dateOfJoining", doj);
					empDetails.put("salary", salary);

					try {
						employeeService.addEmployee(empDetails);
						RequestDispatcher rd = request.getRequestDispatcher("chooseOptions.jsp");
						rd.forward(request, response);
					} catch (EmployeeException e) {
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMsg", e.getMessage());
						rd.forward(request, response);
					}
				

				break;
			}

			case "update": {

				

					String id  = request.getParameter("id");
					String name  = request.getParameter("name");
					String department  = request.getParameter("department");
					String designation  = request.getParameter("designation");
					String dob  = request.getParameter("dob");
					String doj = request.getParameter("doj");
					String salary  = request.getParameter("salary");

					HashMap<String, String> empDetails = new HashMap<String, String>();

					empDetails.put("id", id);
					empDetails.put("name", name);
					empDetails.put("department", department);
					empDetails.put("designation", designation);
					empDetails.put("dateOfBirth", dob);
					empDetails.put("dateOfJoining", doj);
					empDetails.put("salary", salary);

					try {
						employeeService.updateEmployee(empDetails);
						RequestDispatcher rd = request.getRequestDispatcher("chooseOptions.jsp");
						rd.forward(request, response);
					} catch (EmployeeException e) {
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMsg", e.getMessage());
						rd.forward(request, response);
					}

				
				break;
			}

			case "remove": {

				

					String id = request.getParameter("id");
					try {
						employeeService.removeEmployee(id);
						RequestDispatcher rd = request.getRequestDispatcher("removeEmployee.jsp");
						rd.forward(request, response);

					} catch (EmployeeException e) {
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMsg", e.getMessage());
						rd.forward(request, response);
					}

				
				break;
			}

			case "search": {

				

					String id = request.getParameter("id");
					try {
						HashMap<String, String> empDetails = employeeService.searchEmployee(id);
						RequestDispatcher rd = request.getRequestDispatcher("searchEmployee.jsp");
						request.setAttribute("empDetails", empDetails);
						rd.forward(request, response);

					} catch (EmployeeException e) {
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMsg", e.getMessage());
						rd.forward(request, response);
					}
				
				break;
			}

			case "showall": {

				
					try {
						List<HashMap<String, String>> empList = employeeService.getAllEmployee();
						RequestDispatcher rd = request.getRequestDispatcher("showDetails.jsp");
						request.setAttribute("eList", empList);
						rd.forward(request, response);

					} catch(Exception e) {
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMsg", e.getMessage());
						rd.forward(request, response);
					}
				

				break;
			}

			case "fetch": {

				

					String id = request.getParameter("id");
					try {
						HashMap<String, String> empDetails = employeeService.searchEmployee(id);
						RequestDispatcher rd = request.getRequestDispatcher("updateEmployee.jsp");
						request.setAttribute("empDetails", empDetails);
						rd.forward(request, response);

					} catch (EmployeeException e) {
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMsg", e.getMessage());
						rd.forward(request, response);
					}

				

				break;
			}

			default : {

				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMsg", "Invalid Url");
				rd.forward(request, response);
				break;
			}


			}
			
			
			
			
		}


		

	}



}
