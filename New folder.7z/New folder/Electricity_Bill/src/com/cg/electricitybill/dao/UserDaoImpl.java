package com.cg.electricitybill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;



import com.cg.electricitybill.dto.User;
import com.cg.electricitybill.dto.UserPay;
import com.cg.electricitybill.exception.UserException;
import com.cg.electricitybill.factory.DBUtil;

public class UserDaoImpl implements UserDao {

	@Override
	public void addUser(User user) throws UserException {
		Connection con;
		try {
				con = DBUtil.getConnection();
				String query = "INSERT into user_master values(seq_user_master.nextval,?,?,?,?,?)";
				
				PreparedStatement ptmt = con.prepareStatement(query);
				
				ptmt.setString(1, user.getName());
				ptmt.setString(2, user.getMobileNo());
				ptmt.setString(3, user.getUsername());
				ptmt.setString(4, user.getPassword());
				ptmt.setString(5, user.getRePassword());
				ptmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

	@Override
	public void addAmount(UserPay pay) throws UserException {
		Connection con;
		try {
				con = DBUtil.getConnection();
				String query = "INSERT into user_pay_master values(seq_userpay_master.nextval,?,?,?,?)";
				
				PreparedStatement ptmt = con.prepareStatement(query);
				
				ptmt.setString(1, pay.getName());
				ptmt.setString(2, pay.getUsername());
				ptmt.setString(3, pay.getPassword());
				ptmt.setString(4, pay.getAmount());
				
				ptmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

}
