package com.cg.practicetest.dto;

import java.io.Serializable;

public class Employee implements Serializable {
	
	private int empId;
	//private String fName;
	//private String mName;
	//private String lName;
	private String name;
	private String businessName;
	private String emailId;
	private String mobileNum;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name
				+ ", businessName=" + businessName + ", emailId=" + emailId
				+ ", mobileNum=" + mobileNum + "]";
	}
	
	
	
	
	}

	
	


