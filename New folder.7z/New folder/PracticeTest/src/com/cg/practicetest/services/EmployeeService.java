package com.cg.practicetest.services;



import com.cg.practicetest.dto.Employee;
import com.cg.practicetest.exception.EmployeeException;

public interface EmployeeService {
	public long addEmployee(Employee registerDetails) throws EmployeeException;
	public void updateStatus(String email) throws EmployeeException;
	public Employee searchEmployee(Employee registerDetails)throws EmployeeException;
	public void updateEmployee(Employee registerDetails) throws EmployeeException;
}
