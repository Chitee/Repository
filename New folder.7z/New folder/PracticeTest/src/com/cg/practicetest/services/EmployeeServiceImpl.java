package com.cg.practicetest.services;


import com.cg.practicetest.dao.EmployeeDAO;
import com.cg.practicetest.dao.EmployeeDAOImpl;
import com.cg.practicetest.dto.Employee;
import com.cg.practicetest.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDAO empDao = new EmployeeDAOImpl();

	@Override
	public long addEmployee(Employee registerDetails) throws EmployeeException {
		return empDao.addEmployee(registerDetails);
	}

	@Override
	public void updateStatus(String email) throws EmployeeException {
		empDao.updateStatus(email);
		
	}

	@Override
	public void updateEmployee(Employee registerDetails)
			throws EmployeeException {
		
	  empDao.updateEmployee(registerDetails);
		
	}

	@Override
	public Employee searchEmployee(Employee registerDetails) throws EmployeeException {
		return empDao.searchEmployee(registerDetails);
	
	}


	
}
