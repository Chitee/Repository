package com.cg.practicetest.dao;

import com.cg.practicetest.dto.Employee;
import com.cg.practicetest.exception.EmployeeException;



public interface EmployeeDAO {
	public long addEmployee(Employee registerDetails) throws EmployeeException;
	public void updateStatus(String email) throws EmployeeException;
	public Employee searchEmployee(Employee registerDetails)throws EmployeeException;
	public void updateEmployee(Employee registerDetails) throws EmployeeException;
}
