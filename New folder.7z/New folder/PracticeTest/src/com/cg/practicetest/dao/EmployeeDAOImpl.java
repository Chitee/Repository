package com.cg.practicetest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Random;


import com.cg.practicetest.dto.Employee;
import com.cg.practicetest.exception.EmployeeException;
import com.cg.practicetest.factory.DbUtil;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Override
	public long addEmployee(Employee registerDetails) throws EmployeeException {
		
		Connection con;
		try {
				con = DbUtil.getConnection();
				String query = "INSERT into employee_master values(seq_employee_master.nextval,?,?,?,?,?)";
				
				PreparedStatement ptmt = con.prepareStatement(query);
				//String name = registerDetails.getfName()+" "+registerDetails.getmName()+" "+registerDetails.getlName();
				ptmt.setString(1, registerDetails.getName());
				ptmt.setString(2, registerDetails.getBusinessName());
				ptmt.setString(3, registerDetails.getEmailId());
				ptmt.setString(4, registerDetails.getMobileNum());
				ptmt.setString(5, "N");
				ptmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Random rand = new Random(); 
		long value = rand.nextInt(10000)+10000;
		return value;
		
	}

	

	
	@Override
	public void updateStatus(String email) throws EmployeeException {
		try {
			Connection con = DbUtil.getConnection();
			String query = "Update employee_master SET isactive=? WHERE email=?";
			PreparedStatement ptmt = con.prepareStatement(query);
			ptmt.setString(1, "Y");
			ptmt.setString(2, email);
			ptmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}




	@Override
	public void updateEmployee(Employee registerDetails)
			throws EmployeeException {
		 try{
			 	System.out.println(registerDetails);
			    Connection con=DbUtil.getConnection();
				PreparedStatement pstm=con.prepareStatement("update employee_master set owner_name=?,business_name=?,email=?,mobile_no=? where employee_id=?");
				//String name = registerDetails.getfName()+" "+registerDetails.getmName()+" "+registerDetails.getlName();
				pstm.setInt(5, registerDetails.getEmpId());
				pstm.setString(1, registerDetails.getName());
				pstm.setString(2, registerDetails.getBusinessName());
				pstm.setString(3, registerDetails.getEmailId());
				pstm.setString(4, registerDetails.getMobileNum());
				
				pstm.executeUpdate();
				
				//int status = pstm.executeUpdate();
				//System.out.println(status);
			}catch (Exception e) {
				throw new EmployeeException(e);
			}
		
	}




	@Override
	public Employee searchEmployee(Employee registerDetails) throws EmployeeException {
		 try{
			 Connection con=DbUtil.getConnection();
			 PreparedStatement pstm=con.prepareStatement("select * from employee_master where employee_id=?");
			 
			 pstm.setInt(1, registerDetails.getEmpId());
			 
			 ResultSet res=pstm.executeQuery();
			 
			 if(res.next()!=true)
				 throw new EmployeeException("Employee not found with id"+registerDetails.getEmpId());
			 else{
				 	
				 	registerDetails.setName(res.getString("owner_name"));
				 	registerDetails.setBusinessName(res.getString("business_Name"));
				 	registerDetails.setEmailId(res.getString("email"));
					registerDetails.setMobileNum(res.getString("mobile_no"));
				 	
					return registerDetails;
				 }
				}catch(Exception e)
				{
					throw new EmployeeException(e);
				}
	
	}


	

}
