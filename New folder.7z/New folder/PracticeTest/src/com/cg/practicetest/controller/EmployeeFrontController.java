package com.cg.practicetest.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;












import com.cg.practicetest.dto.Employee;
import com.cg.practicetest.exception.EmployeeException;
import com.cg.practicetest.services.EmployeeService;
import com.cg.practicetest.services.EmployeeServiceImpl;



@WebServlet("/EmployeeFrontController")
public class EmployeeFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EmployeeService employeeService;    
    EmployeeService registering;
    public EmployeeFrontController() {
        super();
        registering = new EmployeeServiceImpl();
        employeeService=new EmployeeServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession usersession = request.getSession(true);
		switch(action.toLowerCase())
		{
		case "register":
			{
				
				Employee emp = new Employee();
				/*List<Employee> registerDetails = new ArrayList<>();*/
				
				//String fName = request.getParameter("fname");
				//String mName = request.getParameter("mname");
				//String lName = request.getParameter("lname");
				String name= request.getParameter("name");
				String businessName = request.getParameter("businessName");
				String email = request.getParameter("email");
				String mobile = request.getParameter("mobile");
				
				//emp.setfName(fName);
				//emp.setmName(mName);
				//emp.setlName(lName);
				emp.setName(name);
				emp.setBusinessName(businessName);
				emp.setEmailId(email);
				emp.setMobileNum(mobile);
				//registerDetails.add(emp);
				
				long activationCode = 0;
				try {
					
					activationCode = registering.addEmployee(emp);
				} catch (EmployeeException e) {
					
					RequestDispatcher rd = request.getRequestDispatcher("errorpage.jsp");
					request.setAttribute("errorMsg", "Registration Failed. Please try again ");
					rd.forward(request, response);
				}
				
				String code = String.valueOf(activationCode);
				usersession.setAttribute("activationCode",code);
				usersession.setAttribute("email", email);
				
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				request.setAttribute("code", code);
				rd.forward(request, response);
				
				
			}
			break;
		case "activation":
			{
				String email = request.getParameter("email");
				String activationCode = request.getParameter("activationCode");
				
				String sessionCode = (String)usersession.getAttribute("activationCode");
				String sessionEmail = (String)usersession.getAttribute("email");
				// Validation for the activation(Matching session values and user input values)
				if(email.equals(sessionEmail)&&activationCode.equals(sessionCode))
				{
					try {
						registering.updateStatus(email);
					} catch (EmployeeException e) {
						RequestDispatcher rd = request.getRequestDispatcher("errorpage.jsp");
						request.setAttribute("errorMsg", "Activation Failed. Please try again. ");
						rd.forward(request, response);
					}
					RequestDispatcher rd = request.getRequestDispatcher("activated.jsp");
					rd.forward(request, response);
				}
				else
				{
					RequestDispatcher rd = request.getRequestDispatcher("errorpage.jsp");
					request.setAttribute("errorMsg", "Your account could not be activated due to incorrect Email-Id or Activation Code");
					rd.forward(request, response);
				}
				
			}
			break;
			
		case "fetch":
		{
			/*String empId1= request.getParameter("empId");
			int empId=Integer.parseInt(empId1);
			*/
			int empId = Integer.parseInt(request.getParameter("empId"));
			System.out.println(empId);
			try {
				Employee emp=new Employee();
				emp.setEmpId(empId);
				Employee registerDetails = employeeService.searchEmployee(emp);
				RequestDispatcher rd=request.getRequestDispatcher("update.jsp");
				request.setAttribute("registerDetails", registerDetails);
				rd.forward(request, response);
				
			} catch(EmployeeException e) {
				
				RequestDispatcher rd=request.getRequestDispatcher("errorpage.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
		}
		break;
		
		case "update":
		{
			Employee emp=new Employee();
			
				//String fName = request.getParameter("fname");
				//String mName = request.getParameter("mname");
				//String lName = request.getParameter("lname");
				int empId=Integer.parseInt(request.getParameter("empId"));
				String name= request.getParameter("name");
				String businessName = request.getParameter("businessName");
				String email = request.getParameter("email");
				String mobile = request.getParameter("mobile");
				
			//	emp.setfName(fName);
			//	emp.setmName(mName);
			//	emp.setlName(lName);
				emp.setEmpId(empId);
				emp.setName(name);
				emp.setBusinessName(businessName);
				emp.setEmailId(email);
				emp.setMobileNum(mobile);
				
				
				try {
					employeeService.updateEmployee(emp);
					
					RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
					rd.forward(request, response);
					
				} catch (EmployeeException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("errorpage.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
				
			
				/*long activationCode = 0;
				try {
					
					activationCode = registering.addEmployee(emp);
				} catch (EmployeeException e) {
					
					RequestDispatcher rd = request.getRequestDispatcher("errorpage.jsp");
					request.setAttribute("errorMsg", "Registration Failed. Please try again ");
					rd.forward(request, response);
				}
				
				String code = String.valueOf(activationCode);
				usersession.setAttribute("activationCode",code);
				usersession.setAttribute("email", email);
				
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				request.setAttribute("code", code);
				rd.forward(request, response);*/
		}
		break;
		}
	}

}
